package model;

public enum Demarcacion {
    PORTERO,
    DEFENSA,
    CENTROCAMPISTA,
    DELANTERO,
    MIXTO;
}
