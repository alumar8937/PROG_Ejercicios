// 10/01/2023 Pedro Marín Sanchis

public class Main5 {
    public static void main(String[] args) {
        Rectangulo r = new Rectangulo();
        System.out.println(r.toString());
        r.desplaza(4, 7);
        System.out.println(r.toString());
    }
}
