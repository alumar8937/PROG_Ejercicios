// 20/12/2022 Pedro Marín Sanchis

public class Main {

    public static void main(String[] args) {

        Punto p1 = new Punto(4, 3);
        System.out.println(p1.toString());
        p1.posiciona(-3, 1);
        System.out.println(p1.toString());
        
    }
    
}
