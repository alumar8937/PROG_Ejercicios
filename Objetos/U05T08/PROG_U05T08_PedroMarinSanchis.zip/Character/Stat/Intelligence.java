package Character.Stat;

public class Intelligence extends Stat {

    public String toString() {
        return "Intelligence";
    }
    
}
