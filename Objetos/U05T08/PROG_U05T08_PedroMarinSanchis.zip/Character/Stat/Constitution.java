package Character.Stat;

public class Constitution extends Stat {

    public String toString() {
        return "Constitution";
    }
    
}
