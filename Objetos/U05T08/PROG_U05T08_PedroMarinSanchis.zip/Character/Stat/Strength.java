package Character.Stat;

public class Strength extends Stat {

    public String toString() {
        return "Strength";
    }
    
}
