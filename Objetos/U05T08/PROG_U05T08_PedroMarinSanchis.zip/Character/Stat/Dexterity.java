package Character.Stat;

public class Dexterity extends Stat {

    public String toString() {
        return "Dexterity";
    }
    
}
