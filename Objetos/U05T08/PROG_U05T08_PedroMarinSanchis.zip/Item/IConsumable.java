package Item;

import Character.RPGCharacter;

public interface IConsumable {

    void consumedBy(RPGCharacter character);
    
}
