package Item.Food;

public class Behelit extends Food {

    public Behelit() {
        this.power = 500;
    }

    public String toString() {
        return "Behelit";
    }
    
}
