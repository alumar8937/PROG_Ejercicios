package Item.Food;

public class Chicken extends Food {

    public Chicken() {
        this.power = 25;
    }

    public String toString() {
        return "Chicken";
    }

}
