package Item.Food;

public class Carrot extends Food {

    public Carrot() {
        this.power = 3;
    }

    public String toString() {
        return "Carrot";
    }

}
