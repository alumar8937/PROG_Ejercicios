package Item.Food;

public class Bread extends Food {

    public Bread() {
        this.power = 10;
    }

    public String toString() {
        return "Bread";
    }

}
