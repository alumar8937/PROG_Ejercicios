package Item.Food;

public class Apple extends Food {
    public Apple() {
        this.power = 5;
    }

    public String toString() {
        return "Apple";
    }
}
