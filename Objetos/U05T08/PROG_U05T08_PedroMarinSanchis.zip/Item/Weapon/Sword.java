package Item.Weapon;

public class Sword extends Weapon {
    
    public Sword() {
        super();
        this.damage = 10;
    }

    public String toString() {
        return "Sword";
    }
    
}
