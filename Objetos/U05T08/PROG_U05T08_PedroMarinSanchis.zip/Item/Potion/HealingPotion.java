package Item.Potion;

public class HealingPotion extends Potion {

    public HealingPotion() {
        super();
        this.power = 50;
    }

    public String toString() {
        return "Healing Potion";
    }
    
}
