package Item.Gear;

public class Shirt extends Gear {
    
    public Shirt() {
        super();
        this.CON_MODIFIER = 1;
    }

    public String toString() {
        return "Shirt";
    }

}
