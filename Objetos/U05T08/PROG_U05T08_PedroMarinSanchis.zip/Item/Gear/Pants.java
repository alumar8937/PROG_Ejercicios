package Item.Gear;

public class Pants extends Gear {

    public Pants() {
        super();
        this.CON_MODIFIER = 1;

    }

    public String toString() {
        return "Pants";
    }

}
