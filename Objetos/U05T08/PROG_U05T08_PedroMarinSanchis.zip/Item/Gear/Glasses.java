package Item.Gear;

public class Glasses extends Gear {
    
    public Glasses() {
        super();
        this.INT_MODIFIER = 1;
    }

    public String toString() {
        return "Glasses";
    }

}
