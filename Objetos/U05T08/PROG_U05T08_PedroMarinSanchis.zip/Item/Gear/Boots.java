package Item.Gear;

public class Boots extends Gear {
    
    public Boots() {
        super();
        this.DEX_MODIFIER = 1;
    }

    public String toString() {
        return "Boots";
    }

}
