// Intended to test weight mechanics.

package Item;

public class LeadBrick extends Item {

    public LeadBrick() {
        super();
        this.weight = 500;
    }

    public String toString() {
        return "Lead Brick";
    }
    
}
