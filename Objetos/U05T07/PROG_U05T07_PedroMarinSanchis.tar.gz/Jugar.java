public interface Jugar {
    void saltarPorUnAro();

    void perseguirUnObjeto(String objeto);
}
