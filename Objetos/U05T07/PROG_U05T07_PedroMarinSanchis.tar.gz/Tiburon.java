public class Tiburon extends Pez{
    
    public Tiburon(String nombre) {
        super(nombre);
    }

    public void comunicarse() {
        System.out.println("[Banda sonora de JAWS]");
    }

}
