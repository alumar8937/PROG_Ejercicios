package PedroMarinSanchis.Ejercicio2.Biblioteca.Video;

public interface IContainsVideo {
    public int getDurationInMinutes();
    public int getRelease();
}
