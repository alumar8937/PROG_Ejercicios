//21_09_2022 Pedro Marín Sanchis

public class Java_Basico_EJ3 {

    public static void main(String[] args) {
    
        int ladoCuadrado = 5;
        
        int squareArea = (ladoCuadrado * ladoCuadrado);
        
        System.out.println("The square's area is: " + squareArea + " units.");
    
    
    }

}
