//19_09_2022 Pedro Marín Sanchis

public class Java_Basico_EJ1 {

    public static void main(String[] args) {
    
        double dividendo =20.0;
        
        double divisor = 6.0;
        
        double sumarAlFinal = 3.0;
        
        System.out.println((dividendo/divisor) + sumarAlFinal);
    
    }

}
