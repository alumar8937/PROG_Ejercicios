//19_09_2022 Pedro Marín Sanchis

public class Java_Basico_EJ2 {

    public static void main(String[] args) {
    
        int dividendo = 20;
        
        int divisor = 6;
        
        int sumarAlFinal = 3;
        
        System.out.println((dividendo/divisor) + sumarAlFinal);
    
    }

}
